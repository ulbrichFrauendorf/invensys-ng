# Component demo reference

Approved baseline: the Confirmation Dialog demo, including the user's final header changes, on 15 October 2026. Apply this design to the remaining component demos. Installation and Theming keep their documentation layouts.

## Layout and interaction

- Put the component title in an unstyled `h3` inside the left card header, with a paragraph below showing **Preview** or **Code**. Do not add a separate page header.
- Use one sticky card on the left and a vertical options checklist on the right. Options scroll with the page.
- Use an accessible icon button in the card header: code icon with **View code**, then eye icon with **View preview**. Replace the card content when switching views; retain the selected options.
- Include all component options. Keep required options checked and explain why. Expose editable values when an option needs them.
- Generate copyable code from the same configuration used by the preview. Unchecked optional properties are omitted.
- Put any necessary Usage Notes below the playground. Do not add Features blocks.

## Styling

- Reuse `projects/ui-kit/src/app/components/demo-playground.styles.scss` for layout and `demo-playground.theme.scss` for shared colors.
- Add `demo-playground` to the demo's root element. The confirmation dialog template is the markup reference.
- Keep component-specific preview styles in its component stylesheet, and colors in its `.theme.scss` file. Include the theme mixin after layout rules so border and outline shorthand declarations cannot reset theme colors.
- Let headings and paragraphs use application typography. Do not override their fonts, sizes, weights, margins, or colors.
- Use pixel units for fixed dimensions and spacing, never `rem`. Preserve percentages, fractional grid tracks, and viewport calculations where layout needs them.
- The reference uses a 1200px maximum width, 24px spacing, a 280–360px options column, and a 480px card content area. At 800px and below, stack the cards and use a 240px content area.

## Snapshot

[`snapshots/confirmation-dialog-demo-2026-10-15.zip`](snapshots/confirmation-dialog-demo-2026-10-15.zip) preserves the approved source files and this guide with their repository-relative paths. The accompanying JSON manifest records SHA-256 hashes. This is a source checkpoint; it does not change Git history.

The live reference is `/components/confirmation-dialogs` in the UI kit.
